﻿using System.ComponentModel.DataAnnotations;

namespace Biblos2.Models
{
    public class LibroCreacionViewModel
    {
        public Libros libros { get; set; }
        [Display(Name = "Nombre del libro")]
        public string nombre { get; set; }

        [Display(Name = "Precio")]
        public int precio { get; set; }
        
        public string Autor { get; set; }
        public string Estado { get; set; }
        [Display(Name = "Año de publicación")]
        public int FechaPublicacion { get; set; }
    }
}
