﻿namespace Biblos2.Models
{
    public class UsuariosListadoViewModel
    {
        public List<UsuariosViewModel> Usuarios { get; set; }
        public string Mensajes { get; set; }
    }
}
