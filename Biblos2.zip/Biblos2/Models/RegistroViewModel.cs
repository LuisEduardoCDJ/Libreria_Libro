﻿using System.ComponentModel.DataAnnotations;

namespace Biblos2.Models
{
    public class RegistroViewModel
    {
        [Required(ErrorMessage = "Este campo es requerido!")]
        [EmailAddress(ErrorMessage = "Agregue un correo valido")]
        public string Email { get; set; }

        [DataType(DataType.Password)]
        [Required(ErrorMessage = "Ingrese su contraseña")]
        public string Password { get; set; }
    }
}
