﻿namespace Biblos2.Models
{
    public class UsuariosViewModel
    {
        public string Email { get; set; }
    }
}
