﻿namespace Biblos2.Models
{
    public class ListadoLibrosViewModel
    {
        public List<Libros> listadoLibros { get; set; }
    }
}
