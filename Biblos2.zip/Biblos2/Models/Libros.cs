﻿using Microsoft.Identity.Client;
using System.ComponentModel.DataAnnotations;

namespace Biblos2.Models
{
    public class Libros
    {
        public int Id { get; set; }
        [Display(Name = "Nombre del libro")]
        [Required(ErrorMessage = "Agregue el nombre del libro")]
        public string? Nombre { get; set; }

        [Required(ErrorMessage = "Agregue el nombre del autor del libro")]
        public string? Autor { get; set; }
        [Display(Name = "Año de publicación")]
        public int FechaPublicacion { get; set; }
        [Required(ErrorMessage = "Agregue el precio del libro")]
        public float Precio { get; set; }

        [Required(ErrorMessage = "Agregue el número de copias")]
        [Display(Name = "Número de copias")]
        public int stock { get; set; }
    }
}
