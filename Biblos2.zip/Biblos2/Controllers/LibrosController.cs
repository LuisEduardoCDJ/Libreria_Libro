﻿
using Biblos2.Models;
using Biblos2.Servicios;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Abstractions;
using System.Data;

namespace Biblos2.Controllers
{
    public class LibrosController : Controller
    {
        private readonly ApplicationDbContext context;

        public LibrosController(ApplicationDbContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public ActionResult Index()
        {

            var libros = context.Libros.Select(u => new Libros
            {
                Nombre = u.Nombre,
                Autor = u.Autor,
                FechaPublicacion = u.FechaPublicacion,
                stock = u.stock,
                Precio = u.Precio

            }).ToList();

            var listado = new ListadoLibrosViewModel();

            listado.listadoLibros = libros;
            return View(listado);
        }

        [HttpGet]

        public ActionResult IndexNew()
        {
            var libros = context.Libros.Select(u => new Libros
            {
                Nombre = u.Nombre,
                Autor = u.Autor,
                FechaPublicacion = u.FechaPublicacion,
                stock = u.stock,
                Precio = u.Precio

            }).ToList();

            var listado = new ListadoLibrosViewModel();

            listado.listadoLibros = libros;
            return View(listado);
        }

        //[HttpGet]
        //public Task<ActionResult> Vendidos()
        //{

        //}

        [HttpGet]
        [Authorize(Roles = Constantes.RolAdmin)]
        public ActionResult Crear()
        {
            return View();
        }

        [HttpPost]
        [Authorize(Roles = Constantes.RolAdmin)]
        public async Task<IActionResult> Crear(Libros libros)
        {

            if (ModelState.IsValid)
            {
                context.Add(libros);
                await context.SaveChangesAsync();
            }

            return RedirectToAction("Index");

        }

        [HttpGet]
        public async Task<IActionResult> Editar(int? id)
        {
            if (id == null)
            {
                Console.WriteLine("Yessir");
                return NotFound();
            }

            var libro = context.Libros.FirstOrDefault(l => l.Id == id);


            return View(libro);
        }

        [HttpGet]
        public ActionResult Inventario()
        {
            var libros = context.Libros.Select(u => new Libros
            {
                Nombre = u.Nombre,
                Autor = u.Autor,
                FechaPublicacion = u.FechaPublicacion,
                stock = u.stock,
                Precio = u.Precio

            }).ToList();

            var listado = new ListadoLibrosViewModel();

            listado.listadoLibros = libros;
            return View(listado);
        }



    }
}
