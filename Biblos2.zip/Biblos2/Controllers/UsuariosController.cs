﻿using Biblos2.Models;
using Biblos2.Servicios;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Biblos2.Controllers
{
    public class UsuariosController: Controller
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly SignInManager<IdentityUser> signInManager;
        private readonly ApplicationDbContext context;

        //Inyectando la dependencia identity para la seguridad a nivel del controlador.
        public UsuariosController(UserManager<IdentityUser> userManager,
            SignInManager<IdentityUser> signInManager,
            ApplicationDbContext context)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this.context = context;
        }

        [AllowAnonymous]
        public ActionResult Registro()
        {

            return View();

        }

        //Action para registrarse en la aplicacion
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Registro(RegistroViewModel modelo)
        {
            if (!ModelState.IsValid)
            {
                return View(modelo);
            }

            var usuario = new IdentityUser()
            {
                Email = modelo.Email,
                UserName = modelo.Email
            };

            var resultado = await userManager.CreateAsync(usuario, password: modelo.Password);

            if (resultado.Succeeded)
            {
                await signInManager.SignInAsync(usuario, isPersistent: true);
                return RedirectToAction("Index", "Home");
            }
            else
            {
                foreach (var error in resultado.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }

                return View(modelo);
            }
        }

        [AllowAnonymous]
        public ActionResult Login(string mensaje = null)
        {
            if (mensaje is not null)
            {
                ViewData["mensaje"] = mensaje;
            }
            return View();
        }

        //Action para loguarse en la aplicacion
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Login(LoginViewModel modelo)
        {
            if (!ModelState.IsValid)
            {
                return View(modelo);
            }

            var resultado = await signInManager.PasswordSignInAsync(modelo.Email, modelo.Password, modelo.Recuerdame
                , lockoutOnFailure: false);

            if (resultado.Succeeded)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Nombre de usuario o password incorrecto.");
                return View(modelo);
            }
        }

        //Action para desloguearse de la aplicacion
        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(IdentityConstants.ApplicationScheme);
            return RedirectToAction("Index", "Home");
        }

        //Necesitamos mostrar el listado de usuarios.
        [HttpGet]
        //Dandole acceso a esta accion a un rol especifico
        //[Authorize(Roles = Constantes.RolAdmin)]
        public async Task<IActionResult> Listado(string mensaje = null)
        {
            var usuario = await context.Users.Select(u => new UsuariosViewModel
            {
                Email = u.Email,

            }).ToListAsync();

            var modelo = new UsuariosListadoViewModel();
            modelo.Usuarios = usuario;
            modelo.Mensajes = mensaje;
            return View(modelo);
        }

        //Para colocar el rol de admin a un usuario
        [HttpPost]
        //Dandole acceso a esta accion a un rol especifico
        [Authorize(Roles = Constantes.RolAdmin)]
        public async Task<IActionResult> HacerAdmin(string email)
        {
            var usuario = await context.Users.Where(u => u.Email == email).FirstOrDefaultAsync();

            //Si el email no existe
            if (usuario == null)
            {
                return NotFound();
            }

            //Si el email existe, necesitamos agregar el rol de admin al email que obtenemos, usando 
            //AddRoleAsync.
            await userManager.AddToRoleAsync(usuario, Constantes.RolAdmin);

            //Luego necesitamos redireccionar al usuario, dejando claro con un mensaje que el rol fue asignado.
            return RedirectToAction("Listado",
                routeValues: new { mensaje = "Rol asignado correctamente a " + email });

        }

        //Para remover el rol de admin a un usuario
        [HttpPost]
        //Dandole acceso a esta accion a un rol especifico
        [Authorize(Roles = Constantes.RolAdmin)]
        public async Task<IActionResult> RemoverAdmin(string email)
        {
            var usuario = await context.Users.Where(u => u.Email == email).FirstOrDefaultAsync();

            //Si el email no existe
            if (usuario == null)
            {
                return NotFound();
            }

            //Si el email existe, necesitamos remover el rol de admin del email que obtenemos, usando 
            //RemoveFromRoleAsync.
            await userManager.RemoveFromRoleAsync(usuario, Constantes.RolAdmin);

            //Luego necesitamos redireccionar al usuario, dejando claro con un mensaje que el rol fue removido.
            return RedirectToAction("Listado",
                routeValues: new { mensaje = "Rol removido correctamente a " + email });

        }

    }
}
