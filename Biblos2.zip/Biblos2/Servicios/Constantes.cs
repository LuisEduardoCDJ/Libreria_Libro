﻿namespace Biblos2.Servicios
{
    public class Constantes
    {
        public const string RolAdmin = "admin";
    }
}
